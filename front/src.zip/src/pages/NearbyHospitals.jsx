import React, { useEffect, useState } from "react";
import axios from "axios";
import MapDisplay from "../components/MapDisplay";
import "../styles/NearbyHospitals.css";

const NearbyHospitals = () => {
  const [location, setLocation] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [topHospitals, setTopHospitals] = useState([]);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = {
          lat: pos.coords.latitude,
          lon: pos.coords.longitude,
        };
        setLocation(coords);

        axios
          .get(`http://localhost:5000/get-hospitals?lat=${coords.lat}&lon=${coords.lon}`)
          .then((res) => {
            const fetchedHospitals = res.data.hospitals || [];
            setHospitals(fetchedHospitals);

            const sortedHospitals = [...fetchedHospitals].sort((a, b) => a.distance - b.distance);
            setTopHospitals(sortedHospitals.slice(0, 3));
          })
          .catch((err) => {
            console.error("Error fetching hospitals:", err);
          });
      },
      (err) => {
        console.error("Geolocation error:", err);
        alert("Unable to access your location.");
      }
    );
  }, []);

  return (
    <div className="nearby-hospitals-wrapper">
      {/* Map on left */}
      <div className="map-left-section">
        <MapDisplay userLocation={location} hospitals={hospitals} />
      </div>

      {/* Top 3 hospitals on right */}
      <div className="top-hospitals-section">
        <h3>Top 3 Nearby Hospitals</h3>
        <ul className="top-hospital-list">
          {topHospitals.map((hospital, idx) => (
            <li key={idx} className="hospital-card">
              <strong>{hospital.Name}</strong><br />
              📍 {hospital.Address}<br />
              🩺 Doctor: {hospital["Doctor name"]}<br />
              📏 {hospital.distance.toFixed(2)} km away<br />
              <em>{hospital.Description}</em>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default NearbyHospitals;
