import React from "react";
import "../styles/LandingPage.css";

const LandingPage = () => {
  return (
    <div className="landing">
      <h1>Kidney Disease Prediction System</h1>
      <p>
        This project helps predict kidney diseases using kidney CT scan images.
        Patients upload a scan and provide their location. The system predicts
        the disease and shows nearby hospitals for further treatment.
      </p>
      <h2>How It Works:</h2>
      <ol>
        <li>Upload kidney CT image</li>
        <li>Enter your location</li>
        <li>Get prediction result</li>
        <li>Find top 3 nearest hospitals</li>
      </ol>
      <button className="cta-button" onClick={() => window.location.href = "/predict"}>
        Get Started
        </button>

    </div>
  );
};

export default LandingPage;
