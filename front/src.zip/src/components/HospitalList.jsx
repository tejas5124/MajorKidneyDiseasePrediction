import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import hospitals from "./HospitalList.json";
import L from "leaflet";

const HospitalList = () => {
  return (
    <div className="hospital-list">
      <h3>All Hospitals</h3>
      {/* Table Listing Hospitals */}
      <table className="hospital-table">
        <thead>
          <tr>
            <th>Sr. No</th>
            <th>Hospital Name</th>
            <th>Location</th>
          </tr>
        </thead>
        <tbody>
          {hospitals.map((h, i) => (
            <tr key={i}>
              <td>{i + 1}</td> {/* Sr. No */}
              <td>{h.Name}</td>
              <td>{h.Location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default HospitalList;
