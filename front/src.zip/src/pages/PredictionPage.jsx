import React, { useState } from "react";
import axios from "axios";
import "../styles/PredictionPage.css";

const PredictionPage = () => {
  const [image, setImage] = useState(null);
  const [location, setLocation] = useState("");
  const [result, setResult] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!image || !location) return alert("Please upload image and location.");

    const formData = new FormData();
    formData.append("image", image);
    formData.append("location", location);

    try {
      const res = await axios.post("http://localhost:5000/predict", formData);
      setResult(res.data.prediction);
    } catch (err) {
      console.error(err);
      setResult("Error predicting disease.");
    }
  };

  return (
    <div className="prediction-page">
      <h2>Disease Prediction</h2>
      <form onSubmit={handleSubmit}>
        <input type="file" accept="image/*" onChange={(e) => setImage(e.target.files[0])} />
        <input
          type="text"
          placeholder="Enter your city or location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />
        <button type="submit">Predict</button>
      </form>
      {result && <p className="result">Result: {result}</p>}
    </div>
  );
};

export default PredictionPage;
